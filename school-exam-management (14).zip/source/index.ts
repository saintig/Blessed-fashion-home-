import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-api-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const response = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

class RequestError extends Error {
  status: number;

  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

function validInteger(value: unknown, min: number, max: number) {
  return Number.isInteger(value) &&
    Number(value) >= min &&
    Number(value) <= max;
}

function validPositiveNumber(value: unknown, max = 10000) {
  return typeof value === "number" &&
    Number.isFinite(value) &&
    value > 0 &&
    value <= max;
}

function parseOptionalDate(value: unknown, label: string): string | null {
  if (value === null || value === undefined || value === "") return null;

  if (typeof value !== "string") {
    throw new RequestError(`${label} must be a valid date and time.`);
  }

  const date = new Date(value);

  if (!Number.isFinite(date.getTime())) {
    throw new RequestError(`${label} must be a valid date and time.`);
  }

  return date.toISOString();
}

function generateExaminationCode() {
  const values = new Uint32Array(1);
  crypto.getRandomValues(values);

  return `STIG-EXM${1000000 + (values[0] % 9000000)}`;
}

function validateExamFields(input: any) {
  const title = String(input.title ?? "").trim();
  const nameClass = String(input.name_class ?? "").trim();
  const description = String(input.description ?? "").trim();

  const subjectId = Number(input.school_subject_id);
  const duration = Number(input.duration_minutes);
  const questionCount = Number(input.student_question_count);

  const maxAttempts = input.max_attempts === undefined
    ? 2
    : Number(input.max_attempts);

  const marksPerQuestion = input.marks_per_question === undefined
    ? 1
    : Number(input.marks_per_question);

  const startsAt = parseOptionalDate(input.starts_at, "Start date and time");
  const endsAt = parseOptionalDate(input.ends_at, "End date and time");

  if (!title || title.length > 200) {
    throw new RequestError("Enter a valid examination title.");
  }

  if (nameClass.length > 200) {
    throw new RequestError(
      "Examination name and class must not exceed 200 characters."
    );
  }

  if (!Number.isSafeInteger(subjectId) || subjectId <= 0) {
    throw new RequestError("Select a valid subject.");
  }

  if (!validInteger(duration, 1, 100)) {
    throw new RequestError("Duration must be between 1 and 100 minutes.");
  }

  if (!validInteger(questionCount, 1, 500)) {
    throw new RequestError("Question count must be between 1 and 500.");
  }

  if (!validInteger(maxAttempts, 1, 5)) {
    throw new RequestError("Maximum attempts must be between 1 and 5.");
  }

  if (!validPositiveNumber(marksPerQuestion)) {
    throw new RequestError("Marks per question must be a positive number.");
  }

  if (description.length > 5000) {
    throw new RequestError("Examination instructions are too long.");
  }

  if (startsAt && endsAt && new Date(endsAt) <= new Date(startsAt)) {
    throw new RequestError(
      "The end date and time must be after the start date and time."
    );
  }

  return {
    title,
    name_class: nameClass || null,
    description: description || null,
    subjectId,
    duration,
    questionCount,
    maxAttempts,
    marksPerQuestion,
    startsAt,
    endsAt,
  };
}

function validateQuestion(q: any, index: number, defaultMarks = 1) {
  const label = `Question ${index + 1}`;

  if (!q || typeof q !== "object" || Array.isArray(q)) {
    throw new RequestError(`${label} is invalid.`);
  }

  const question_text = String(q.question_text ?? "").trim();
  const option_a = String(q.option_a ?? "").trim();
  const option_b = String(q.option_b ?? "").trim();
  const option_c = String(q.option_c ?? "").trim();
  const option_d = String(q.option_d ?? "").trim();

  const correct_option = String(q.correct_option ?? "")
    .trim()
    .toUpperCase();

  const explanation = String(q.explanation ?? "").trim();

  if (!question_text) {
    throw new RequestError(`${label}: enter the question text.`);
  }

  if (question_text.length > 20000) {
    throw new RequestError(`${label}: question text is too long.`);
  }

  const options = [
    ["Option A", option_a],
    ["Option B", option_b],
    ["Option C", option_c],
    ["Option D", option_d],
  ];

  for (const [name, value] of options) {
    if (!value) {
      throw new RequestError(`${label}: ${name} is required.`);
    }

    if (value.length > 10000) {
      throw new RequestError(`${label}: ${name} is too long.`);
    }
  }

  if (!["A", "B", "C", "D"].includes(correct_option)) {
    throw new RequestError(
      `${label}: correct option must be A, B, C or D.`
    );
  }

  const marks =
    q.marks === null || q.marks === undefined || q.marks === ""
      ? defaultMarks
      : Number(q.marks);

  if (!validPositiveNumber(marks)) {
    throw new RequestError(`${label}: marks must be a positive number.`);
  }

  if (!validInteger(q.question_order, 1, 2147483647)) {
    throw new RequestError(
      `${label}: question order must be a positive integer.`
    );
  }

  if (explanation.length > 20000) {
    throw new RequestError(`${label}: explanation is too long.`);
  }

  return {
    question_text,
    option_a,
    option_b,
    option_c,
    option_d,
    correct_option,
    explanation: explanation || null,
    marks,
    question_order: q.question_order,
    image_path: null,
    is_published: true,
    is_archived: false,
  };
}

/*
 * Editing a question must not reset its image, publication
 * status or archive status.
 */
function validateQuestionUpdate(q: any) {
  const validated = validateQuestion(q, 0, 1);

  return {
    question_text: validated.question_text,
    option_a: validated.option_a,
    option_b: validated.option_b,
    option_c: validated.option_c,
    option_d: validated.option_d,
    correct_option: validated.correct_option,
    explanation: validated.explanation,
    marks: validated.marks,
    question_order: validated.question_order,
  };
}

/* =========================================================
   PACKAGE MANAGEMENT HELPERS
========================================================= */

type PackageInfo = {
  package_name: string;
  max_active_students: number;
  max_subjects: number;
  max_stored_questions: number;
  max_examinations: number;
  max_exam_duration_minutes: number;
  max_questions_per_exam: number;
};

function packageLimit(
  customValue: unknown,
  standardValue: unknown,
  label: string
): number {
  const value =
    customValue !== null && customValue !== undefined
      ? Number(customValue)
      : Number(standardValue);

  if (!Number.isSafeInteger(value) || value < 1) {
    throw new RequestError(
      `The ${label} limit for your package is not configured correctly.`,
      500
    );
  }

  return value;
}

/*
 * Retrieves all package limits.
 *
 * Custom values override standard package limits.
 * A Custom package without a standard limits row uses Free
 * as its fallback for any limit without a custom value.
 */
async function getStudentPackage(
  db: any,
  accountId: number
): Promise<PackageInfo> {
  const { data: assignment, error: assignmentError } = await db
    .from("school_account_packages")
    .select(`
      package_name,
      custom_max_active_students,
      custom_max_subjects,
      custom_max_stored_questions,
      custom_max_examinations,
      custom_max_exam_duration_minutes,
      custom_max_questions_per_exam
    `)
    .eq("school_account_id", accountId)
    .maybeSingle();

  if (assignmentError) {
    console.error("Package assignment lookup:", assignmentError);

    throw new RequestError(
      "Unable to verify your package.",
      500
    );
  }

  const packageName = String(assignment?.package_name || "Free");

  let { data: limits, error: limitsError } = await db
    .from("school_package_limits")
    .select(`
      package_name,
      max_active_students,
      max_subjects,
      max_stored_questions,
      max_examinations,
      max_exam_duration_minutes,
      max_questions_per_exam
    `)
    .eq("package_name", packageName)
    .maybeSingle();

  if (limitsError) {
    console.error("Package limits lookup:", limitsError);

    throw new RequestError(
      "Unable to retrieve your package limits.",
      500
    );
  }

  if (!limits && packageName.toLowerCase() === "custom") {
    const fallback = await db
      .from("school_package_limits")
      .select(`
        package_name,
        max_active_students,
        max_subjects,
        max_stored_questions,
        max_examinations,
        max_exam_duration_minutes,
        max_questions_per_exam
      `)
      .eq("package_name", "Free")
      .maybeSingle();

    if (fallback.error) {
      console.error("Free package fallback:", fallback.error);

      throw new RequestError(
        "Unable to retrieve the default package limits.",
        500
      );
    }

    limits = fallback.data;
  }

  if (!limits) {
    throw new RequestError(
      `The ${packageName} package has no configured limits.`,
      500
    );
  }

  return {
    package_name: packageName,

    max_active_students: packageLimit(
      assignment?.custom_max_active_students,
      limits.max_active_students,
      "active student"
    ),

    max_subjects: packageLimit(
      assignment?.custom_max_subjects,
      limits.max_subjects,
      "subject"
    ),

    max_stored_questions: packageLimit(
      assignment?.custom_max_stored_questions,
      limits.max_stored_questions,
      "stored question"
    ),

    max_examinations: packageLimit(
      assignment?.custom_max_examinations,
      limits.max_examinations,
      "examination"
    ),

    max_exam_duration_minutes: packageLimit(
      assignment?.custom_max_exam_duration_minutes,
      limits.max_exam_duration_minutes,
      "examination duration"
    ),

    max_questions_per_exam: packageLimit(
      assignment?.custom_max_questions_per_exam,
      limits.max_questions_per_exam,
      "questions per examination"
    ),
  };
}

/*
 * Counts active, non-archived students.
 */
async function countActiveStudents(
  db: any,
  accountId: number,
  excludeStudentId?: number
): Promise<number> {
  let query = db
    .from("school_students")
    .select("id", { count: "exact", head: true })
    .eq("school_account_id", accountId)
    .eq("is_active", true)
    .eq("is_archived", false);

  if (excludeStudentId !== undefined) {
    query = query.neq("id", excludeStudentId);
  }

  const { count, error } = await query;

  if (error) {
    console.error("Active student count:", error);

    throw new RequestError(
      "Unable to check your active student count.",
      500
    );
  }

  return count ?? 0;
}

/*
 * Counts active, non-archived subjects.
 * The database trigger independently enforces this limit
 * when subjects are created or restored.
 */
async function countActiveSubjects(
  db: any,
  accountId: number
): Promise<number> {
  const { count, error } = await db
    .from("school_subjects")
    .select("id", { count: "exact", head: true })
    .eq("school_account_id", accountId)
    .eq("is_archived", false);

  if (error) {
    console.error("Active subject count:", error);

    throw new RequestError(
      "Unable to check your active subject count.",
      500
    );
  }

  return count ?? 0;
}

/*
 * Counts non-archived examinations, including drafts.
 * A draft occupies an examination slot because it has
 * already been created in the account.
 */
async function countActiveExaminations(
  db: any,
  accountId: number
): Promise<number> {
  const { count, error } = await db
    .from("examinations")
    .select("id", { count: "exact", head: true })
    .eq("school_account_id", accountId)
    .eq("is_archived", false);

  if (error) {
    console.error("Active examination count:", error);

    throw new RequestError(
      "Unable to check your examination count.",
      500
    );
  }

  return count ?? 0;
}

/*
 * Counts all stored questions belonging to the account.
 *
 * Archived questions are included because they still occupy
 * storage in the database. Questions in archived examinations
 * are also included until those records are permanently removed.
 *
 * Examination IDs are fetched in pages and question counts
 * are queried in smaller batches to avoid oversized requests.
 */
async function countStoredQuestions(
  db: any,
  accountId: number
): Promise<number> {
  let total = 0;
  let offset = 0;
  const pageSize = 1000;
  const batchSize = 100;

  while (true) {
    const { data: exams, error: examsError } = await db
      .from("examinations")
      .select("id")
      .eq("school_account_id", accountId)
      .order("id", { ascending: true })
      .range(offset, offset + pageSize - 1);

    if (examsError) {
      console.error("Stored question examination lookup:", examsError);

      throw new RequestError(
        "Unable to check your stored question count.",
        500
      );
    }

    const rows = exams ?? [];
    const ids = rows
      .map((exam: any) => Number(exam.id))
      .filter((id: number) => Number.isSafeInteger(id) && id > 0);

    for (let i = 0; i < ids.length; i += batchSize) {
      const batch = ids.slice(i, i + batchSize);

      const { count, error } = await db
        .from("exam_questions")
        .select("id", { count: "exact", head: true })
        .in("examination_id", batch);

      if (error) {
        console.error("Stored question count:", error);

        throw new RequestError(
          "Unable to check your stored question count.",
          500
        );
      }

      total += count ?? 0;
    }

    if (rows.length < pageSize) break;

    offset += pageSize;
  }

  return total;
}

/*
 * Enforces examination duration and the number of questions
 * each student will receive.
 */
function enforceExamPackageLimits(
  fields: any,
  packageInfo: PackageInfo
) {
  if (fields.duration > packageInfo.max_exam_duration_minutes) {
    throw new RequestError(
      `Your ${packageInfo.package_name} package allows a maximum examination duration of ${packageInfo.max_exam_duration_minutes} minutes.`,
      409
    );
  }

  if (fields.questionCount > packageInfo.max_questions_per_exam) {
    throw new RequestError(
      `Your ${packageInfo.package_name} package allows a maximum of ${packageInfo.max_questions_per_exam} questions per examination.`,
      409
    );
  }
}

/* =========================================================
   DELETE SAFETY HELPERS
========================================================= */

const PROTECTED_RECORD_CODE = "23503";

/*
 * Reads every question of an examination, page by page.
 * Used to keep a copy before the questions are removed so they
 * can be restored if the examination itself cannot be deleted.
 */
async function fetchAllExamQuestions(
  db: any,
  examinationId: number
): Promise<any[]> {
  const all: any[] = [];
  const pageSize = 1000;
  let offset = 0;

  while (true) {
    const { data, error } = await db
      .from("exam_questions")
      .select("*")
      .eq("examination_id", examinationId)
      .order("id", { ascending: true })
      .range(offset, offset + pageSize - 1);

    if (error) throw error;

    const rows = data ?? [];
    all.push(...rows);

    if (rows.length < pageSize) break;

    offset += pageSize;
  }

  return all;
}

async function restoreExamQuestions(db: any, questions: any[]) {
  const chunkSize = 200;

  for (let i = 0; i < questions.length; i += chunkSize) {
    const chunk = questions.slice(i, i + chunkSize);

    const { error } = await db.from("exam_questions").insert(chunk);

    if (error) {
      console.error("Question restore after failed delete:", error);
      return false;
    }
  }

  return true;
}

/* =========================================================
   STUDENT MANAGEMENT HELPERS
========================================================= */

function getStudentDatabaseId(value: unknown): number {
  const id = Number(value);

  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new RequestError("Select a valid student.");
  }

  return id;
}

function validateStudentName(value: unknown): string {
  const name = String(value ?? "").trim();

  if (!name || name.length > 200) {
    throw new RequestError(
      "Enter a valid student full name. Maximum length is 200 characters."
    );
  }

  return name;
}

async function getOwnedStudent(
  db: any,
  accountId: number,
  studentDatabaseId: number
) {
  const { data: student, error } = await db
    .from("school_students")
    .select(`
      id,
      school_account_id,
      student_id,
      full_name,
      is_active,
      is_archived,
      created_at,
      updated_at,
      archived_at
    `)
    .eq("id", studentDatabaseId)
    .eq("school_account_id", accountId)
    .maybeSingle();

  if (error) {
    console.error("Student lookup:", error);

    throw new RequestError(
      "Unable to retrieve this student.",
      500
    );
  }

  if (!student) {
    throw new RequestError(
      "Student not found in your account.",
      404
    );
  }

  return student;
}

async function getStudentAttemptStatistics(
  db: any,
  accountId: number
) {
  const statistics = new Map<
    number,
    { attempt_count: number; result_count: number }
  >();

  let offset = 0;
  const pageSize = 1000;

  while (true) {
    const { data: attempts, error } = await db
      .from("exam_attempts")
      .select("student_id, score")
      .eq("school_account_id", accountId)
      .not("student_id", "is", null)
      .range(offset, offset + pageSize - 1);

    if (error) {
      console.error("Student attempt statistics:", error);

      throw new RequestError(
        "Unable to retrieve student examination statistics.",
        500
      );
    }

    const rows = attempts ?? [];

    for (const attempt of rows) {
      const studentId = Number(attempt.student_id);

      if (!Number.isSafeInteger(studentId)) continue;

      const current = statistics.get(studentId) ?? {
        attempt_count: 0,
        result_count: 0,
      };

      current.attempt_count++;

      if (attempt.score !== null && attempt.score !== undefined) {
        current.result_count++;
      }

      statistics.set(studentId, current);
    }

    if (rows.length < pageSize) break;

    offset += pageSize;
  }

  return statistics;
}

/* =========================================================
   MAIN EDGE FUNCTION
========================================================= */

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return response({ error: "Method not allowed." }, 405);
  }

  try {
    const authorization = req.headers.get("Authorization");

    if (!authorization?.startsWith("Bearer ")) {
      throw new RequestError("Please sign in first.", 401);
    }

    const jwt = authorization.substring(7);

    const authClient = createClient(
      SUPABASE_URL,
      SUPABASE_ANON_KEY,
      {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
        global: {
          headers: {
            Authorization: `Bearer ${jwt}`,
          },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await authClient.auth.getUser();

    if (authError || !user) {
      throw new RequestError(
        "Your session is invalid. Please sign in again.",
        401
      );
    }

    const db = createClient(
      SUPABASE_URL,
      SUPABASE_SERVICE_ROLE_KEY,
      {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      }
    );

    const body = await req.json();

    if (!body || typeof body.action !== "string") {
      throw new RequestError("A valid action is required.");
    }

    const { data: account, error: accountError } = await db
      .from("school_accounts")
      .select("id, user_id, account_name, account_type, status")
      .eq("user_id", user.id)
      .maybeSingle();

    if (accountError) {
      console.error("Account lookup:", accountError);

      throw new RequestError(
        "Unable to verify your account.",
        500
      );
    }

    if (
      !account ||
      account.status !== "active" ||
      !["teacher", "school"].includes(account.account_type)
    ) {
      throw new RequestError(
        "You do not have an active Teacher/School account.",
        403
      );
    }

    /* =====================================================
       STUDENT ACTION 1: LIST STUDENTS
    ===================================================== */

    if (body.action === "list_students") {
      const includeArchived = body.include_archived === true;

      let studentQuery = db
        .from("school_students")
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .eq("school_account_id", account.id);

      if (!includeArchived) {
        studentQuery = studentQuery.eq("is_archived", false);
      }

      const { data: students, error: studentError } =
        await studentQuery
          .order("created_at", { ascending: false })
          .limit(5000);

      if (studentError) {
        console.error("Student retrieval:", studentError);

        throw new RequestError(
          "Unable to retrieve your students.",
          500
        );
      }

      const packageInfo = await getStudentPackage(db, account.id);

      const statistics = await getStudentAttemptStatistics(
        db,
        account.id
      );

      const studentList = (students ?? []).map((student: any) => {
        const stats = statistics.get(Number(student.id)) ?? {
          attempt_count: 0,
          result_count: 0,
        };

        return { ...student, ...stats };
      });

      const activeCount = await countActiveStudents(
        db,
        account.id
      );

      const { count: archivedCount, error: archivedCountError } =
        await db
          .from("school_students")
          .select("id", { count: "exact", head: true })
          .eq("school_account_id", account.id)
          .eq("is_archived", true);

      if (archivedCountError) {
        console.error("Archived student count:", archivedCountError);

        throw new RequestError(
          "Unable to retrieve archived student count.",
          500
        );
      }

      return response({
        success: true,
        students: studentList,
        package: packageInfo,
        active_students_count: activeCount,
        archived_students_count: archivedCount ?? 0,
      });
    }

    /* =====================================================
       STUDENT ACTION 2: ADD STUDENT
    ===================================================== */

    if (body.action === "add_student") {
      const fullName = validateStudentName(body.full_name);
      const packageInfo = await getStudentPackage(db, account.id);

      const activeCount = await countActiveStudents(
        db,
        account.id
      );

      if (activeCount >= packageInfo.max_active_students) {
        throw new RequestError(
          `You have reached your ${packageInfo.package_name} package limit of ${packageInfo.max_active_students} active student(s). Deactivate or archive a student, or upgrade your package to add another student.`,
          409
        );
      }

      const { data: student, error: insertError } = await db
        .from("school_students")
        .insert({
          school_account_id: account.id,
          full_name: fullName,
          is_active: true,
          is_archived: false,
        })
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .single();

      if (insertError || !student) {
        console.error("Student registration:", insertError);

        throw new RequestError(
          "Unable to register this student. Please try again.",
          400
        );
      }

      return response({
        success: true,
        message: "Student registered successfully.",
        student: {
          ...student,
          attempt_count: 0,
          result_count: 0,
        },
      });
    }

    /* =====================================================
       STUDENT ACTION 3: UPDATE STUDENT NAME
    ===================================================== */

    if (body.action === "update_student") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);
      const fullName = validateStudentName(body.full_name);

      const existingStudent = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      if (existingStudent.is_archived) {
        throw new RequestError(
          "Restore this student before editing the name.",
          409
        );
      }

      const { data: updatedStudent, error: updateError } = await db
        .from("school_students")
        .update({
          full_name: fullName,
          updated_at: new Date().toISOString(),
        })
        .eq("id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .eq("is_archived", false)
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .single();

      if (updateError || !updatedStudent) {
        console.error("Student update:", updateError);

        throw new RequestError(
          "Unable to update this student.",
          400
        );
      }

      return response({
        success: true,
        message: "Student details updated successfully.",
        student: updatedStudent,
      });
    }

    /* =====================================================
       STUDENT ACTION 4: ACTIVATE / DEACTIVATE STUDENT
    ===================================================== */

    if (body.action === "set_student_status") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);

      if (typeof body.is_active !== "boolean") {
        throw new RequestError("A valid student status is required.");
      }

      const existingStudent = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      if (existingStudent.is_archived) {
        throw new RequestError(
          "Restore this student before changing the status.",
          409
        );
      }

      if (
        body.is_active === true &&
        existingStudent.is_active !== true
      ) {
        const packageInfo = await getStudentPackage(db, account.id);

        const activeCount = await countActiveStudents(
          db,
          account.id,
          studentDatabaseId
        );

        if (activeCount >= packageInfo.max_active_students) {
          throw new RequestError(
            `You have reached your ${packageInfo.package_name} package limit of ${packageInfo.max_active_students} active student(s). Deactivate or archive another student, or upgrade your package.`,
            409
          );
        }
      }

      const { data: updatedStudent, error: updateError } = await db
        .from("school_students")
        .update({
          is_active: body.is_active,
          updated_at: new Date().toISOString(),
        })
        .eq("id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .eq("is_archived", false)
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .single();

      if (updateError || !updatedStudent) {
        console.error("Student status update:", updateError);

        throw new RequestError(
          "Unable to change this student's status.",
          400
        );
      }

      return response({
        success: true,
        message: body.is_active
          ? "Student activated successfully."
          : "Student deactivated successfully.",
        student: updatedStudent,
      });
    }

    /* =====================================================
       STUDENT ACTION 5: ARCHIVE STUDENT
    ===================================================== */

    if (body.action === "archive_student") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);

      const existingStudent = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      if (existingStudent.is_archived) {
        throw new RequestError(
          "This student is already archived.",
          409
        );
      }

      const now = new Date().toISOString();

      const { data: archivedStudent, error: archiveError } = await db
        .from("school_students")
        .update({
          is_active: false,
          is_archived: true,
          archived_at: now,
          updated_at: now,
        })
        .eq("id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .eq("is_archived", false)
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .single();

      if (archiveError || !archivedStudent) {
        console.error("Student archive:", archiveError);

        throw new RequestError(
          "Unable to archive this student.",
          400
        );
      }

      return response({
        success: true,
        message: "Student archived successfully. Examination history has been preserved.",
        student: archivedStudent,
      });
    }

    /* =====================================================
       STUDENT ACTION 6: RESTORE ARCHIVED STUDENT
    ===================================================== */

    if (body.action === "restore_student") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);

      const existingStudent = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      if (!existingStudent.is_archived) {
        throw new RequestError(
          "This student is not archived.",
          409
        );
      }

      const packageInfo = await getStudentPackage(db, account.id);
      const activeCount = await countActiveStudents(db, account.id);

      if (activeCount >= packageInfo.max_active_students) {
        throw new RequestError(
          `You have reached your ${packageInfo.package_name} package limit of ${packageInfo.max_active_students} active student(s). Deactivate or archive another student, or upgrade your package before restoring this student.`,
          409
        );
      }

      const { data: restoredStudent, error: restoreError } = await db
        .from("school_students")
        .update({
          is_active: true,
          is_archived: false,
          archived_at: null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .eq("is_archived", true)
        .select(`
          id,
          school_account_id,
          student_id,
          full_name,
          is_active,
          is_archived,
          created_at,
          updated_at,
          archived_at
        `)
        .single();

      if (restoreError || !restoredStudent) {
        console.error("Student restoration:", restoreError);

        throw new RequestError(
          "Unable to restore this student.",
          400
        );
      }

      return response({
        success: true,
        message: "Student restored successfully. The original Student ID and examination history have been preserved.",
        student: restoredStudent,
      });
    }

    /* =====================================================
       STUDENT ACTION 7: DELETE STUDENT WHEN SAFE
    ===================================================== */

    if (body.action === "delete_student") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);

      const existingStudent = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      /*
       * Exam attempts are checked by student only, so attempts saved
       * under any account id still protect the student.
       */
      const { count: attemptCount, error: attemptError } = await db
        .from("exam_attempts")
        .select("id", { count: "exact", head: true })
        .eq("student_id", studentDatabaseId);

      if (attemptError) {
        console.error("Student history check:", attemptError);

        throw new RequestError(
          "Unable to verify this student's examination history.",
          500
        );
      }

      if ((attemptCount ?? 0) > 0) {
        throw new RequestError(
          "This student has examination history or results and cannot be permanently deleted. Archive the student instead.",
          409
        );
      }

      /*
       * Class results are history and protect the student from deletion.
       * If this check itself fails, the database restriction on
       * school_class_result_students still protects the records.
       */
      const { count: classResultCount, error: classResultError } = await db
        .from("school_class_result_students")
        .select("id", { count: "exact", head: true })
        .eq("school_student_id", studentDatabaseId);

      if (classResultError) {
        console.error("Class result check:", classResultError);
      } else if ((classResultCount ?? 0) > 0) {
        throw new RequestError(
          "This student has class results and cannot be permanently deleted. Archive the student instead.",
          409
        );
      }

      const { data: deletedStudent, error: deleteError } = await db
        .from("school_students")
        .delete()
        .eq("id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .select("id")
        .maybeSingle();

      if (deleteError) {
        console.error("Student deletion:", deleteError);

        if (deleteError.code === PROTECTED_RECORD_CODE) {
          throw new RequestError(
            "This student is linked to other records, such as classes or results, and cannot be permanently deleted. Archive the student instead.",
            409
          );
        }

        throw new RequestError(
          "Unable to delete this student. Please try again or archive the student instead.",
          409
        );
      }

      if (!deletedStudent) {
        throw new RequestError(
          "Student not found or could not be deleted.",
          404
        );
      }

      return response({
        success: true,
        message: "Student permanently deleted.",
        student_id: existingStudent.student_id,
      });
    }

    /* =====================================================
       STUDENT ACTION 8: STUDENT DETAILS AND HISTORY
    ===================================================== */

    if (body.action === "student_details") {
      const studentDatabaseId = getStudentDatabaseId(body.student_db_id);

      const student = await getOwnedStudent(
        db,
        account.id,
        studentDatabaseId
      );

      const { data: attempts, error: attemptsError } = await db
        .from("exam_attempts")
        .select(`
          id,
          examination_id,
          started_at,
          submitted_at,
          status,
          score,
          total_marks,
          question_count,
          duration_minutes,
          created_at
        `)
        .eq("student_id", studentDatabaseId)
        .eq("school_account_id", account.id)
        .order("started_at", { ascending: false })
        .limit(1000);

      if (attemptsError) {
        console.error("Student examination history:", attemptsError);

        throw new RequestError(
          "Unable to retrieve this student's examination history.",
          500
        );
      }

      const examinationIds = [
        ...new Set(
          (attempts ?? []).map((attempt: any) =>
            Number(attempt.examination_id)
          )
        ),
      ].filter((id: number) =>
        Number.isSafeInteger(id) && id > 0
      );

      let examinations: any[] = [];

      if (examinationIds.length > 0) {
        const { data: examRows, error: examsError } = await db
          .from("examinations")
          .select(`
            id,
            title,
            examination_code,
            name_class,
            school_subject_id
          `)
          .eq("school_account_id", account.id)
          .in("id", examinationIds);

        if (examsError) {
          console.error("Student history examinations:", examsError);

          throw new RequestError(
            "Unable to retrieve examination details.",
            500
          );
        }

        examinations = examRows ?? [];
      }

      const examinationMap = new Map<number, any>(
        examinations.map((exam: any) => [
          Number(exam.id),
          exam,
        ])
      );

      const studentAttempts = (attempts ?? []).map((attempt: any) => {
        const exam = examinationMap.get(Number(attempt.examination_id));

        return {
          ...attempt,
          examination_title: exam?.title ?? "Examination",
          examination_code: exam?.examination_code ?? "",
          examination_class: exam?.name_class ?? "",
        };
      });

      const resultCount = studentAttempts.filter(
        (attempt: any) =>
          attempt.score !== null && attempt.score !== undefined
      ).length;

      return response({
        success: true,
        student: {
          ...student,
          attempt_count: studentAttempts.length,
          result_count: resultCount,
        },
        attempts: studentAttempts,
      });
    }

    /* =====================================================
       ACTION 1: LIST SUBJECTS
    ===================================================== */

    if (body.action === "list_subjects") {
      const { data: subjects, error } = await db
        .from("school_subjects")
        .select("id, subject_name, is_published, is_archived")
        .eq("school_account_id", account.id)
        .eq("is_published", true)
        .eq("is_archived", false)
        .order("subject_name", { ascending: true });

      if (error) {
        console.error("Subject retrieval:", error);

        throw new RequestError(
          "Unable to retrieve your subjects.",
          500
        );
      }

      const packageInfo = await getStudentPackage(db, account.id);
      const activeSubjectsCount = await countActiveSubjects(
        db,
        account.id
      );

      return response({
        success: true,
        subjects: subjects ?? [],
        package: packageInfo,
        active_subjects_count: activeSubjectsCount,
      });
    }

    /* =====================================================
       ACTION 2: LIST EXAMINATIONS
    ===================================================== */

    if (body.action === "list_exams") {
      const includeArchived = body.include_archived === true;

      let query = db
        .from("examinations")
        .select(`
          id,
          title,
          name_class,
          description,
          school_subject_id,
          duration_minutes,
          student_question_count,
          marks_per_question,
          starts_at,
          ends_at,
          examination_code,
          max_attempts,
          access_type,
          price,
          is_published,
          is_archived,
          created_at
        `)
        .eq("school_account_id", account.id);

      if (!includeArchived) {
        query = query.eq("is_archived", false);
      }

      const { data: examinations, error } = await query
        .order("created_at", { ascending: false })
        .limit(500);

      if (error) {
        console.error("Examination retrieval:", error);

        throw new RequestError(
          "Unable to retrieve your examinations.",
          500
        );
      }

      const packageInfo = await getStudentPackage(db, account.id);
      const activeExaminationsCount = await countActiveExaminations(
        db,
        account.id
      );
      const storedQuestionsCount = await countStoredQuestions(
        db,
        account.id
      );

      return response({
        success: true,
        examinations: examinations ?? [],
        package: packageInfo,
        active_examinations_count: activeExaminationsCount,
        stored_questions_count: storedQuestionsCount,
      });
    }

    /* =====================================================
       ACTION 3: LIST QUESTIONS
    ===================================================== */

    if (body.action === "list_questions") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const { data: examination, error: examError } = await db
        .from("examinations")
        .select(`
          id,
          title,
          name_class,
          description,
          school_account_id,
          is_published,
          is_archived,
          student_question_count,
          marks_per_question,
          examination_code
        `)
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);

        throw new RequestError(
          "Unable to verify the examination.",
          500
        );
      }

      if (!examination || examination.is_archived) {
        throw new RequestError(
          "Examination not found or unavailable.",
          404
        );
      }

      const { data: questions, error: questionError } = await db
        .from("exam_questions")
        .select(`
          id,
          examination_id,
          question_text,
          option_a,
          option_b,
          option_c,
          option_d,
          correct_option,
          explanation,
          marks,
          question_order,
          image_path,
          is_published,
          is_archived
        `)
        .eq("examination_id", examinationId)
        .eq("is_archived", false)
        .order("question_order", { ascending: true })
        .limit(500);

      if (questionError) {
        console.error("Question retrieval:", questionError);

        throw new RequestError(
          "Unable to retrieve examination questions.",
          500
        );
      }

      return response({
        success: true,
        examination,
        question_count: questions?.length ?? 0,
        questions: questions ?? [],
      });
    }

    /* =====================================================
       ACTION 4: CREATE EXAMINATION
    ===================================================== */

    if (body.action === "create_exam") {
      const fields = validateExamFields(body);
      const packageInfo = await getStudentPackage(db, account.id);

      enforceExamPackageLimits(fields, packageInfo);

      const activeExaminationsCount = await countActiveExaminations(
        db,
        account.id
      );

      if (activeExaminationsCount >= packageInfo.max_examinations) {
        throw new RequestError(
          `You have reached your ${packageInfo.package_name} package limit of ${packageInfo.max_examinations} active examination(s). Archive an examination or upgrade your package to create another.`,
          409
        );
      }

      const { data: subject, error: subjectError } = await db
        .from("school_subjects")
        .select("id")
        .eq("id", fields.subjectId)
        .eq("school_account_id", account.id)
        .eq("is_published", true)
        .eq("is_archived", false)
        .maybeSingle();

      if (subjectError) {
        console.error("Subject lookup:", subjectError);

        throw new RequestError(
          "Unable to verify the selected subject.",
          500
        );
      }

      if (!subject) {
        throw new RequestError(
          "This subject is unavailable or does not belong to your account.",
          403
        );
      }

      const values = {
        title: fields.title,
        name_class: fields.name_class,
        description: fields.description,
        school_account_id: account.id,
        school_subject_id: subject.id,
        subject_id: null,
        duration_minutes: fields.duration,
        student_question_count: fields.questionCount,
        marks_per_question: fields.marksPerQuestion,
        starts_at: fields.startsAt,
        ends_at: fields.endsAt,
        max_attempts: fields.maxAttempts,
        access_type: "free",
        price: 0,
        is_published: false,
        is_archived: false,
      };

      let examination: any = null;
      let insertError: any = null;

      for (let attempt = 0; attempt < 5; attempt++) {
        const result = await db
          .from("examinations")
          .insert({
            ...values,
            examination_code: generateExaminationCode(),
          })
          .select(`
            id,
            title,
            name_class,
            description,
            school_subject_id,
            duration_minutes,
            student_question_count,
            marks_per_question,
            starts_at,
            ends_at,
            max_attempts,
            examination_code,
            is_published
          `)
          .single();

        examination = result.data;
        insertError = result.error;

        if (!insertError) break;
        if (insertError.code !== "23505") break;
      }

      if (insertError || !examination) {
        console.error("Examination creation:", insertError);

        throw new RequestError(
          "Unable to create the examination. Please try again.",
          400
        );
      }

      return response({
        success: true,
        message: "Examination draft created.",
        examination,
      });
    }

    /* =====================================================
       ACTION 4B: UPDATE EXAMINATION
    ===================================================== */

    if (body.action === "update_exam") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const fields = validateExamFields(body);
      const packageInfo = await getStudentPackage(db, account.id);

      enforceExamPackageLimits(fields, packageInfo);

      const { data: existingExam, error: existingExamError } = await db
        .from("examinations")
        .select("id, is_published, is_archived, examination_code")
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (existingExamError) {
        console.error("Examination lookup:", existingExamError);

        throw new RequestError(
          "Unable to verify the examination.",
          500
        );
      }

      if (!existingExam || existingExam.is_archived) {
        throw new RequestError(
          "Examination not found or unavailable.",
          404
        );
      }

      if (existingExam.is_published) {
        throw new RequestError(
          "Only draft examinations can be edited.",
          409
        );
      }

      const { data: subject, error: subjectError } = await db
        .from("school_subjects")
        .select("id")
        .eq("id", fields.subjectId)
        .eq("school_account_id", account.id)
        .eq("is_published", true)
        .eq("is_archived", false)
        .maybeSingle();

      if (subjectError) {
        console.error("Subject lookup:", subjectError);

        throw new RequestError(
          "Unable to verify the selected subject.",
          500
        );
      }

      if (!subject) {
        throw new RequestError(
          "This subject is unavailable or does not belong to your account.",
          403
        );
      }

      const { data: updated, error: updateError } = await db
        .from("examinations")
        .update({
          title: fields.title,
          name_class: fields.name_class,
          description: fields.description,
          school_subject_id: subject.id,
          duration_minutes: fields.duration,
          student_question_count: fields.questionCount,
          marks_per_question: fields.marksPerQuestion,
          starts_at: fields.startsAt,
          ends_at: fields.endsAt,
          max_attempts: fields.maxAttempts,
        })
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .eq("is_published", false)
        .select(`
          id,
          title,
          name_class,
          description,
          school_subject_id,
          duration_minutes,
          student_question_count,
          marks_per_question,
          starts_at,
          ends_at,
          max_attempts,
          examination_code,
          is_published
        `)
        .single();

      if (updateError || !updated) {
        console.error("Examination update:", updateError);

        throw new RequestError(
          "Unable to update this examination.",
          400
        );
      }

      return response({
        success: true,
        message: "Examination draft updated.",
        examination: updated,
      });
    }

    /* =====================================================
       ACTION 5: SAVE QUESTIONS
    ===================================================== */

    if (body.action === "save_questions") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      if (!Array.isArray(body.questions) || body.questions.length < 1) {
        throw new RequestError(
          "Send at least one question to save. Drafts may be saved without questions."
        );
      }

      if (body.questions.length > 500) {
        throw new RequestError(
          "A maximum of 500 questions can be saved per request."
        );
      }

      const { data: examination, error: examError } = await db
        .from("examinations")
        .select(`
          id,
          school_account_id,
          is_published,
          is_archived,
          marks_per_question
        `)
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);

        throw new RequestError(
          "Unable to verify the examination.",
          500
        );
      }

      if (!examination || examination.is_archived) {
        throw new RequestError(
          "Examination not found or unavailable.",
          404
        );
      }

      if (examination.is_published) {
        throw new RequestError(
          "Unpublish the examination before adding more questions.",
          409
        );
      }

      const packageInfo = await getStudentPackage(db, account.id);
      const storedQuestionsCount = await countStoredQuestions(
        db,
        account.id
      );

      if (
        storedQuestionsCount + body.questions.length >
        packageInfo.max_stored_questions
      ) {
        const remaining = Math.max(
          0,
          packageInfo.max_stored_questions - storedQuestionsCount
        );

        throw new RequestError(
          `Your ${packageInfo.package_name} package allows ${packageInfo.max_stored_questions} stored questions. You currently have ${storedQuestionsCount}, so you can add only ${remaining} more question(s). Upgrade your package to store more questions.`,
          409
        );
      }

      const questions = body.questions.map(
        (q: any, index: number) =>
          validateQuestion(
            q,
            index,
            Number(examination.marks_per_question ?? 1)
          )
      );

      const orders = questions.map((q: any) => q.question_order);

      if (new Set(orders).size !== orders.length) {
        throw new RequestError(
          "Two or more questions have the same question order."
        );
      }

      const { data: existing, error: existingError } = await db
        .from("exam_questions")
        .select("question_order")
        .eq("examination_id", examinationId)
        .in("question_order", orders);

      if (existingError) {
        console.error("Existing question lookup:", existingError);

        throw new RequestError(
          "Unable to check existing question orders.",
          500
        );
      }

      if (existing?.length) {
        const used = existing
          .map((q: any) => q.question_order)
          .join(", ");

        throw new RequestError(
          `These question order numbers are already in use: ${used}.`
        );
      }

      const rows = questions.map((q: any) => ({
        examination_id: examinationId,
        ...q,
      }));

      const { data: saved, error: saveError } = await db
        .from("exam_questions")
        .insert(rows)
        .select("id, examination_id, question_order");

      if (saveError) {
        console.error("Question saving:", saveError);

        throw new RequestError(
          "Unable to save questions.",
          400
        );
      }

      return response({
        success: true,
        message: `${saved?.length ?? 0} question(s) saved successfully.`,
        saved_count: saved?.length ?? 0,
        questions: saved ?? [],
        stored_questions_count:
          storedQuestionsCount + (saved?.length ?? 0),
        stored_questions_limit: packageInfo.max_stored_questions,
      });
    }

    /* =====================================================
       ACTION 5B: UPDATE ONE EXISTING QUESTION
    ===================================================== */

    if (body.action === "update_question") {
      const questionId = Number(body.question_id);

      if (!Number.isSafeInteger(questionId) || questionId <= 0) {
        throw new RequestError("Select a valid question.");
      }

      const questionFields = validateQuestionUpdate(body.question);

      const { data: existingQuestion, error: questionLookupError } =
        await db
          .from("exam_questions")
          .select("id, examination_id, is_archived")
          .eq("id", questionId)
          .maybeSingle();

      if (questionLookupError) {
        console.error("Question lookup:", questionLookupError);

        throw new RequestError(
          "Unable to verify this question.",
          500
        );
      }

      if (!existingQuestion || existingQuestion.is_archived) {
        throw new RequestError(
          "Question not found or unavailable.",
          404
        );
      }

      const { data: examination, error: examLookupError } = await db
        .from("examinations")
        .select("id, school_account_id, is_published, is_archived")
        .eq("id", existingQuestion.examination_id)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examLookupError) {
        console.error("Examination lookup:", examLookupError);

        throw new RequestError(
          "Unable to verify the associated examination.",
          500
        );
      }

      if (!examination || examination.is_archived) {
        throw new RequestError(
          "The associated examination is unavailable.",
          404
        );
      }

      if (examination.is_published) {
        throw new RequestError(
          "Unpublish the examination before editing its questions.",
          409
        );
      }

      const { data: duplicateOrder, error: orderError } = await db
        .from("exam_questions")
        .select("id")
        .eq("examination_id", examination.id)
        .eq("question_order", questionFields.question_order)
        .neq("id", questionId)
        .eq("is_archived", false)
        .maybeSingle();

      if (orderError) {
        console.error("Question order lookup:", orderError);

        throw new RequestError(
          "Unable to verify the question order.",
          500
        );
      }

      if (duplicateOrder) {
        throw new RequestError(
          "Another question in this examination already uses that question order."
        );
      }

      const { data: updatedQuestion, error: updateQuestionError } =
        await db
          .from("exam_questions")
          .update({
            question_text: questionFields.question_text,
            option_a: questionFields.option_a,
            option_b: questionFields.option_b,
            option_c: questionFields.option_c,
            option_d: questionFields.option_d,
            correct_option: questionFields.correct_option,
            marks: questionFields.marks,
            question_order: questionFields.question_order,
            explanation: questionFields.explanation,
          })
          .eq("id", questionId)
          .eq("examination_id", examination.id)
          .eq("is_archived", false)
          .select(`
            id,
            examination_id,
            question_text,
            option_a,
            option_b,
            option_c,
            option_d,
            correct_option,
            explanation,
            marks,
            question_order,
            image_path,
            is_published,
            is_archived
          `)
          .single();

      if (updateQuestionError || !updatedQuestion) {
        console.error("Question update:", updateQuestionError);

        throw new RequestError(
          "Unable to update this question.",
          400
        );
      }

      return response({
        success: true,
        message: "Question updated successfully.",
        question: updatedQuestion,
      });
    }

    /* =====================================================
       ACTION 6: PUBLISH EXAMINATION
    ===================================================== */

    if (body.action === "publish_exam") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const { data: examination, error: examError } = await db
        .from("examinations")
        .select(`
          id,
          school_account_id,
          student_question_count,
          starts_at,
          ends_at,
          examination_code,
          is_published,
          is_archived,
          duration_minutes
        `)
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);

        throw new RequestError(
          "Unable to verify the examination.",
          500
        );
      }

      if (!examination || examination.is_archived) {
        throw new RequestError(
          "Examination not found or unavailable.",
          404
        );
      }

      if (examination.is_published) {
        throw new RequestError(
          "This examination is already published."
        );
      }

      /*
       * Recheck the current package when publishing.
       * This protects against a package downgrade after
       * the examination draft was created.
       */
      const packageInfo = await getStudentPackage(db, account.id);

      if (
        Number(examination.duration_minutes) >
        packageInfo.max_exam_duration_minutes
      ) {
        throw new RequestError(
          `This examination exceeds your current package duration limit of ${packageInfo.max_exam_duration_minutes} minutes.`,
          409
        );
      }

      if (
        Number(examination.student_question_count) >
        packageInfo.max_questions_per_exam
      ) {
        throw new RequestError(
          `Your current package allows a maximum of ${packageInfo.max_questions_per_exam} questions per examination.`,
          409
        );
      }

      const { count, error: countError } = await db
        .from("exam_questions")
        .select("id", { count: "exact", head: true })
        .eq("examination_id", examinationId)
        .eq("is_published", true)
        .eq("is_archived", false);

      if (countError) {
        console.error("Question count:", countError);

        throw new RequestError(
          "Unable to verify saved questions.",
          500
        );
      }

      if ((count ?? 0) < examination.student_question_count) {
        throw new RequestError(
          `This examination requires at least ${examination.student_question_count} published questions. Currently available: ${count ?? 0}.`
        );
      }

      const { data: updated, error: updateError } = await db
        .from("examinations")
        .update({ is_published: true })
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .eq("is_published", false)
        .select(`
          id,
          title,
          examination_code,
          is_published,
          starts_at,
          ends_at
        `)
        .single();

      if (updateError || !updated) {
        console.error("Examination publication:", updateError);

        throw new RequestError(
          "Unable to publish this examination.",
          400
        );
      }

      return response({
        success: true,
        message: "Examination published successfully.",
        examination: updated,
      });
    }

    /* =====================================================
       ACTION 7: UNPUBLISH EXAMINATION
    ===================================================== */

    if (body.action === "unpublish_exam") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const { data: exam, error } = await db
        .from("examinations")
        .select("id, is_published, is_archived")
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (error) {
        console.error("Examination lookup:", error);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam || exam.is_archived) {
        throw new RequestError("Examination not found.", 404);
      }

      if (!exam.is_published) {
        throw new RequestError("This examination is already unpublished.");
      }

      const { data: updated, error: updateError } = await db
        .from("examinations")
        .update({ is_published: false })
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .eq("is_published", true)
        .select("id, is_published")
        .single();

      if (updateError || !updated) {
        console.error("Unpublish examination:", updateError);
        throw new RequestError("Unable to unpublish this examination.", 400);
      }

      return response({
        success: true,
        message: "Examination unpublished successfully.",
        examination: updated,
      });
    }

    /* =====================================================
       ACTION 8: ARCHIVE EXAMINATION
    ===================================================== */

    if (body.action === "archive_exam") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const { data: exam, error } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (error) {
        console.error("Examination lookup:", error);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam) {
        throw new RequestError("Examination not found.", 404);
      }

      if (exam.is_archived) {
        throw new RequestError("This examination is already archived.");
      }

      const { data: archived, error: archiveError } = await db
        .from("examinations")
        .update({
          is_archived: true,
          is_published: false,
        })
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .select("id, is_archived, is_published")
        .single();

      if (archiveError || !archived) {
        console.error("Archive examination:", archiveError);
        throw new RequestError("Unable to archive this examination.", 400);
      }

      return response({
        success: true,
        message: "Examination archived. Its questions and examination history have been preserved.",
        examination: archived,
      });
    }

    /* =====================================================
       ACTION 9: DELETE EXAMINATION WHEN SAFE
    ===================================================== */

    if (body.action === "delete_exam") {
      const examinationId = Number(body.examination_id);

      if (!Number.isSafeInteger(examinationId) || examinationId <= 0) {
        throw new RequestError("Select a valid examination.");
      }

      const { data: exam, error } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (error) {
        console.error("Examination lookup:", error);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam) {
        throw new RequestError("Examination not found.", 404);
      }

      const { count: attemptCount, error: attemptError } = await db
        .from("exam_attempts")
        .select("id", { count: "exact", head: true })
        .eq("examination_id", examinationId)
        .eq("school_account_id", account.id);

      if (attemptError) {
        console.error("Examination history check:", attemptError);
        throw new RequestError(
          "Unable to verify examination history.",
          500
        );
      }

      if ((attemptCount ?? 0) > 0) {
        if (!exam.is_archived) {
          const { error: archiveError } = await db
            .from("examinations")
            .update({
              is_archived: true,
              is_published: false,
            })
            .eq("id", examinationId)
            .eq("school_account_id", account.id);

          if (archiveError) {
            console.error("Archive examination:", archiveError);
            throw new RequestError(
              "This examination has history and could not be archived.",
              400
            );
          }
        }

        return response({
          success: true,
          archived: true,
          message: "This examination has student history. It has been archived instead of permanently deleted.",
        });
      }

      /*
       * Keep a copy of the questions first. If the examination itself
       * cannot be deleted afterwards, the questions are put back so
       * nothing is lost.
       */
      let questionBackup: any[] = [];

      try {
        questionBackup = await fetchAllExamQuestions(db, examinationId);
      } catch (backupError) {
        console.error("Question backup before delete:", backupError);

        throw new RequestError(
          "Unable to prepare the examination for deletion. Nothing was deleted.",
          500
        );
      }

      const { error: questionDeleteError } = await db
        .from("exam_questions")
        .delete()
        .eq("examination_id", examinationId);

      if (questionDeleteError) {
        console.error("Examination questions deletion:", questionDeleteError);

        if (questionBackup.length > 0) {
          await restoreExamQuestions(db, questionBackup);
        }

        throw new RequestError(
          "Unable to delete the examination questions. The examination was not deleted.",
          409
        );
      }

      const { data: deleted, error: deleteError } = await db
        .from("examinations")
        .delete()
        .eq("id", examinationId)
        .eq("school_account_id", account.id)
        .select("id")
        .maybeSingle();

      if (deleteError || !deleted) {
        console.error("Examination deletion:", deleteError);

        if (questionBackup.length > 0) {
          await restoreExamQuestions(db, questionBackup);
        }

        if (deleteError?.code === PROTECTED_RECORD_CODE) {
          throw new RequestError(
            "This examination is linked to other records and cannot be permanently deleted. Archive it instead. Its questions were kept.",
            409
          );
        }

        throw new RequestError(
          "Unable to delete this examination. Its questions were kept.",
          409
        );
      }

      return response({
        success: true,
        message: "Examination and its questions permanently deleted.",
        examination_id: examinationId,
      });
    }

    /* =====================================================
       ACTION 10: PUBLISH QUESTION
    ===================================================== */

    if (body.action === "publish_question") {
      const questionId = Number(body.question_id);

      if (!Number.isSafeInteger(questionId) || questionId <= 0) {
        throw new RequestError("Select a valid question.");
      }

      const { data: question, error } = await db
        .from("exam_questions")
        .select("id, examination_id, is_published, is_archived")
        .eq("id", questionId)
        .maybeSingle();

      if (error) {
        console.error("Question lookup:", error);
        throw new RequestError("Unable to verify this question.", 500);
      }

      if (!question || question.is_archived) {
        throw new RequestError("Question not found.", 404);
      }

      const { data: exam, error: examError } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", question.examination_id)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam || exam.is_archived) {
        throw new RequestError("Associated examination not found.", 404);
      }

      if (question.is_published) {
        throw new RequestError("This question is already published.");
      }

      const { data: updated, error: updateError } = await db
        .from("exam_questions")
        .update({ is_published: true })
        .eq("id", questionId)
        .eq("examination_id", exam.id)
        .eq("is_archived", false)
        .select("id, is_published, is_archived")
        .single();

      if (updateError || !updated) {
        console.error("Publish question:", updateError);
        throw new RequestError("Unable to publish this question.", 400);
      }

      return response({
        success: true,
        message: "Question published successfully.",
        question: updated,
      });
    }

    /* =====================================================
       ACTION 11: UNPUBLISH QUESTION
    ===================================================== */

    if (body.action === "unpublish_question") {
      const questionId = Number(body.question_id);

      if (!Number.isSafeInteger(questionId) || questionId <= 0) {
        throw new RequestError("Select a valid question.");
      }

      const { data: question, error } = await db
        .from("exam_questions")
        .select("id, examination_id, is_published, is_archived")
        .eq("id", questionId)
        .maybeSingle();

      if (error) {
        console.error("Question lookup:", error);
        throw new RequestError("Unable to verify this question.", 500);
      }

      if (!question || question.is_archived) {
        throw new RequestError("Question not found.", 404);
      }

      const { data: exam, error: examError } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", question.examination_id)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam || exam.is_archived) {
        throw new RequestError("Associated examination not found.", 404);
      }

      if (!question.is_published) {
        throw new RequestError("This question is already unpublished.");
      }

      const { data: updated, error: updateError } = await db
        .from("exam_questions")
        .update({ is_published: false })
        .eq("id", questionId)
        .eq("examination_id", exam.id)
        .eq("is_archived", false)
        .select("id, is_published, is_archived")
        .single();

      if (updateError || !updated) {
        console.error("Unpublish question:", updateError);
        throw new RequestError("Unable to unpublish this question.", 400);
      }

      return response({
        success: true,
        message: "Question unpublished successfully.",
        question: updated,
      });
    }

    /* =====================================================
       ACTION 12: ARCHIVE QUESTION
    ===================================================== */

    if (body.action === "archive_question") {
      const questionId = Number(body.question_id);

      if (!Number.isSafeInteger(questionId) || questionId <= 0) {
        throw new RequestError("Select a valid question.");
      }

      const { data: question, error } = await db
        .from("exam_questions")
        .select("id, examination_id, is_archived")
        .eq("id", questionId)
        .maybeSingle();

      if (error) {
        console.error("Question lookup:", error);
        throw new RequestError("Unable to verify this question.", 500);
      }

      if (!question) {
        throw new RequestError("Question not found.", 404);
      }

      const { data: exam, error: examError } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", question.examination_id)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam || exam.is_archived) {
        throw new RequestError("Associated examination not found.", 404);
      }

      if (question.is_archived) {
        throw new RequestError("This question is already archived.");
      }

      const { data: archived, error: archiveError } = await db
        .from("exam_questions")
        .update({
          is_archived: true,
          is_published: false,
        })
        .eq("id", questionId)
        .eq("examination_id", exam.id)
        .select("id, is_archived, is_published")
        .single();

      if (archiveError || !archived) {
        console.error("Archive question:", archiveError);
        throw new RequestError("Unable to archive this question.", 400);
      }

      return response({
        success: true,
        message: "Question archived successfully.",
        question: archived,
      });
    }

    /* =====================================================
       ACTION 13: DELETE QUESTION WHEN SAFE
    ===================================================== */

    if (body.action === "delete_question") {
      const questionId = Number(body.question_id);

      if (!Number.isSafeInteger(questionId) || questionId <= 0) {
        throw new RequestError("Select a valid question.");
      }

      const { data: question, error } = await db
        .from("exam_questions")
        .select("id, examination_id, is_archived")
        .eq("id", questionId)
        .maybeSingle();

      if (error) {
        console.error("Question lookup:", error);
        throw new RequestError("Unable to verify this question.", 500);
      }

      if (!question) {
        throw new RequestError("Question not found.", 404);
      }

      const { data: exam, error: examError } = await db
        .from("examinations")
        .select("id, is_archived")
        .eq("id", question.examination_id)
        .eq("school_account_id", account.id)
        .maybeSingle();

      if (examError) {
        console.error("Examination lookup:", examError);
        throw new RequestError("Unable to verify the examination.", 500);
      }

      if (!exam) {
        throw new RequestError("Question not found in your account.", 404);
      }

      const { count: attemptCount, error: attemptError } = await db
        .from("exam_attempts")
        .select("id", { count: "exact", head: true })
        .eq("examination_id", exam.id)
        .eq("school_account_id", account.id);

      if (attemptError) {
        console.error("Question history check:", attemptError);
        throw new RequestError(
          "Unable to verify examination history.",
          500
        );
      }

      if ((attemptCount ?? 0) > 0) {
        throw new RequestError(
          "This examination has student history. Archive the question instead of permanently deleting it.",
          409
        );
      }

      const { data: deleted, error: deleteError } = await db
        .from("exam_questions")
        .delete()
        .eq("id", questionId)
        .eq("examination_id", exam.id)
        .select("id")
        .maybeSingle();

      if (deleteError || !deleted) {
        console.error("Question deletion:", deleteError);
        throw new RequestError(
          "Unable to delete this question. Related records may protect it.",
          409
        );
      }

      return response({
        success: true,
        message: "Question permanently deleted.",
        question_id: questionId,
      });
    }

    throw new RequestError("Unsupported action.");
  } catch (error) {
    console.error("School examination management:", error);

    if (error instanceof RequestError) {
      return response(
        { error: error.message },
        error.status
      );
    }

    return response(
      { error: "An unexpected server error occurred." },
      500
    );
  }
});